create database data1 in data1dbs with log;
